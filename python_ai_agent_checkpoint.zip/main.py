import sys
from pathlib import Path

# Add current dir to path
sys.path.append(str(Path(__file__).parent))

from gui import AgentGUI

if __name__ == "__main__":
    app = AgentGUI()
    app.mainloop()
