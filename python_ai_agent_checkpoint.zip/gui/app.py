import threading
from tkinter import messagebox, simpledialog

import customtkinter as ctk

from agent.config import config_manager
from agent.providers import get_provider
from agent.core import AgentOrchestrator

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

SEPARATOR = "-" * 60


class AgentGUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Python AI Agent (Planner & Builder)")
        self.geometry("1200x800")

        self.orchestrator = AgentOrchestrator()
        self.busy = False

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._create_sidebar()
        self._create_chat_area()
        self._load_initial_config()

    # ---------- layout ----------

    def _create_sidebar(self):
        self.sidebar = ctk.CTkScrollableFrame(self, width=360, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")

        ctk.CTkLabel(self.sidebar, text="AI Agent Config",
                     font=ctk.CTkFont(size=20, weight="bold")).pack(anchor="w", padx=10, pady=(15, 10))
        ctk.CTkLabel(self.sidebar, text="LLM Providers & API Keys",
                     font=ctk.CTkFont(size=14, weight="bold")).pack(anchor="w", padx=10, pady=(5, 5))

        self.provider_entries = {}
        self.provider_rows_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        self.provider_rows_frame.pack(fill="x")
        self._rebuild_provider_rows()

        ctk.CTkButton(self.sidebar, text="+ Add Custom Provider", fg_color="#27AE60", hover_color="#219653",
                      command=self.add_custom_provider).pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(self.sidebar, text="Save Keys & Refresh Models",
                      command=self.save_keys_and_refresh).pack(fill="x", padx=10, pady=5)

        ctk.CTkLabel(self.sidebar, text="Model Selection",
                     font=ctk.CTkFont(size=14, weight="bold")).pack(anchor="w", padx=10, pady=(15, 5))

        self.status_label = ctk.CTkLabel(self.sidebar, text="", text_color="gray", wraplength=330, justify="left")
        self.status_label.pack(anchor="w", padx=10)

        ctk.CTkLabel(self.sidebar, text="Planner Model:", anchor="w").pack(anchor="w", padx=10, pady=(4, 2))
        f_plan = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        f_plan.pack(fill="x", padx=10, pady=2)
        self.planner_prov_menu = ctk.CTkOptionMenu(f_plan, values=["-"], width=120,
                                                   command=lambda p: self._refresh_models("planner", p))
        self.planner_prov_menu.pack(side="left", padx=(0, 5))
        self.planner_model_menu = ctk.CTkOptionMenu(f_plan, values=["-"], width=190)
        self.planner_model_menu.pack(side="right", fill="x", expand=True)

        ctk.CTkLabel(self.sidebar, text="Builder Model:", anchor="w").pack(anchor="w", padx=10, pady=(10, 2))
        f_build = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        f_build.pack(fill="x", padx=10, pady=2)
        self.builder_prov_menu = ctk.CTkOptionMenu(f_build, values=["-"], width=120,
                                                   command=lambda p: self._refresh_models("builder", p))
        self.builder_prov_menu.pack(side="left", padx=(0, 5))
        self.builder_model_menu = ctk.CTkOptionMenu(f_build, values=["-"], width=190)
        self.builder_model_menu.pack(side="right", fill="x", expand=True)

        ctk.CTkButton(self.sidebar, text="Save Model Choices",
                      command=self.save_model_choices).pack(fill="x", padx=10, pady=10)

        ctk.CTkLabel(self.sidebar, text="Chat History",
                     font=ctk.CTkFont(size=14, weight="bold")).pack(anchor="w", padx=10, pady=(15, 5))
        ctk.CTkButton(self.sidebar, text="Clear Chat History", fg_color="#C0392B", hover_color="#962D22",
                      command=self.clear_history).pack(fill="x", padx=10, pady=5)

    def _create_chat_area(self):
        self.chat_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.chat_frame.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.chat_frame.grid_columnconfigure(0, weight=1)
        self.chat_frame.grid_rowconfigure(0, weight=1)

        self.chat_box = ctk.CTkTextbox(self.chat_frame, wrap="word", font=ctk.CTkFont(size=14))
        self.chat_box.grid(row=0, column=0, sticky="nsew", pady=(0, 15))
        self.chat_box.configure(state="disabled")

        input_frame = ctk.CTkFrame(self.chat_frame, fg_color="transparent")
        input_frame.grid(row=1, column=0, sticky="ew")
        input_frame.grid_columnconfigure(0, weight=1)

        self.input_field = ctk.CTkEntry(input_frame, height=45, font=ctk.CTkFont(size=14),
                                        placeholder_text="Describe what you want built...")
        self.input_field.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.input_field.bind("<Return>", lambda _e: self.send_prompt())

        self.send_btn = ctk.CTkButton(input_frame, text="Send & Run", width=120, height=45,
                                      font=ctk.CTkFont(size=14, weight="bold"), command=self.send_prompt)
        self.send_btn.grid(row=0, column=1, sticky="e")

    def _rebuild_provider_rows(self):
        for child in self.provider_rows_frame.winfo_children():
            child.destroy()
        self.provider_entries.clear()
        for prov_name, data in config_manager.config["providers"].items():
            row = ctk.CTkFrame(self.provider_rows_frame, fg_color="transparent")
            row.pack(fill="x", padx=10, pady=2)
            ctk.CTkLabel(row, text=prov_name, width=130, anchor="w",
                         font=ctk.CTkFont(size=12)).pack(side="left")
            entry = ctk.CTkEntry(row, placeholder_text="API Key", show="*", width=180)
            entry.pack(side="right", fill="x", expand=True)
            if data.get("api_key"):
                entry.insert(0, data["api_key"])
            self.provider_entries[prov_name] = entry

    def _load_initial_config(self):
        self._set_provider_menus()
        cfg = config_manager.config
        self.planner_prov_menu.set(cfg["planner"]["provider"])
        self.builder_prov_menu.set(cfg["builder"]["provider"])
        # Restore saved model choices immediately, then refresh the lists in background.
        self.planner_model_menu.configure(values=[cfg["planner"]["model"]])
        self.planner_model_menu.set(cfg["planner"]["model"])
        self.builder_model_menu.configure(values=[cfg["builder"]["model"]])
        self.builder_model_menu.set(cfg["builder"]["model"])
        self._refresh_models("planner", cfg["planner"]["provider"], keep_selection=cfg["planner"]["model"])
        self._refresh_models("builder", cfg["builder"]["provider"], keep_selection=cfg["builder"]["model"])
        self.refresh_chat_display()

    def _set_provider_menus(self):
        names = list(config_manager.config["providers"].keys())
        self.planner_prov_menu.configure(values=names)
        self.builder_prov_menu.configure(values=names)

    # ---------- status / thread helpers ----------

    def _status(self, msg: str):
        self.after(0, lambda: self.status_label.configure(text=msg))

    def _run_bg(self, work, on_done=None):
        """Run work() in a thread; call on_done(result_or_exception) on the GUI thread."""
        def runner():
            try:
                result = work()
            except Exception as e:
                result = e
            if on_done:
                self.after(0, lambda: on_done(result))
        threading.Thread(target=runner, daemon=True).start()

    # ---------- providers & models ----------

    def add_custom_provider(self):
        name = simpledialog.askstring("Custom Provider", "Provider name (e.g. DeepInfra):", parent=self)
        if not name:
            return
        url = simpledialog.askstring("Custom Provider", "OpenAI-compatible base URL\n(e.g. https://api.deepinfra.com/v1/openai):", parent=self)
        if not url:
            return
        try:
            config_manager.add_provider(name, url)
        except ValueError as e:
            messagebox.showerror("Cannot add provider", str(e), parent=self)
            return
        self._rebuild_provider_rows()
        self._set_provider_menus()
        self._status(f"Added '{name}'. Enter its API key and click Save Keys & Refresh Models.")

    def save_keys_and_refresh(self):
        for prov, entry in self.provider_entries.items():
            config_manager.config["providers"][prov]["api_key"] = entry.get().strip()
        config_manager.save_config()
        self._status("Keys saved. Refreshing models...")
        self._refresh_models("planner", self.planner_prov_menu.get(), keep_selection=self.planner_model_menu.get())
        self._refresh_models("builder", self.builder_prov_menu.get(), keep_selection=self.builder_model_menu.get())

    def _refresh_models(self, role: str, provider_name: str, keep_selection: str | None = None):
        menu = self.planner_model_menu if role == "planner" else self.builder_model_menu
        menu.configure(values=["Loading..."])
        menu.set("Loading...")

        def work():
            return get_provider(provider_name).fetch_models()

        def done(result):
            if isinstance(result, Exception):
                menu.configure(values=["(fetch failed)"])
                menu.set("(fetch failed)")
                self._status(f"{provider_name}: {result}")
                return
            models = result or []
            if not models:
                self._status(f"{provider_name}: no models returned (check API key / URL).")
                models = [keep_selection] if keep_selection else ["(no models)"]
            menu.configure(values=models)
            chosen = keep_selection if keep_selection in models else models[0]
            menu.set(chosen)
            self._status(f"{provider_name}: {len(models)} models loaded.")

        self._run_bg(work, done)

    def save_model_choices(self):
        cfg = config_manager.config
        cfg["planner"] = {"provider": self.planner_prov_menu.get(), "model": self.planner_model_menu.get()}
        cfg["builder"] = {"provider": self.builder_prov_menu.get(), "model": self.builder_model_menu.get()}
        config_manager.save_config()
        self._status("Model choices saved.")

    # ---------- chat ----------

    def clear_history(self):
        if self.busy:
            messagebox.showwarning("Busy", "Wait for the current run to finish.", parent=self)
            return
        if messagebox.askyesno("Confirm", "Clear all chat history?", parent=self):
            config_manager.clear_history()
            self.refresh_chat_display()

    def refresh_chat_display(self):
        self._write_chat(lambda: self._render_history())

    def _render_history(self):
        for msg in config_manager.load_history():
            role = "User" if msg["role"] == "user" else "Assistant"
            self.chat_box.insert("end", f"\n{role}:\n{msg['content']}\n{SEPARATOR}\n")

    def _write_chat(self, fn):
        self.chat_box.configure(state="normal")
        self.chat_box.delete("1.0", "end")
        fn()
        self.chat_box.see("end")
        self.chat_box.configure(state="disabled")

    def _append(self, text: str):
        self.chat_box.configure(state="normal")
        self.chat_box.insert("end", text)
        self.chat_box.see("end")
        self.chat_box.configure(state="disabled")

    def _set_busy(self, busy: bool):
        self.busy = busy
        self.send_btn.configure(state="disabled" if busy else "normal")

    def send_prompt(self):
        if self.busy:
            return
        prompt = self.input_field.get().strip()
        if not prompt:
            return
        self.input_field.delete(0, "end")
        self._set_busy(True)
        self._append(f"\nUser:\n{prompt}\n{SEPARATOR}\n")

        def work():
            return self.orchestrator.run(
                prompt,
                on_text=lambda chunk: self.after(0, self._append, chunk),
                on_status=lambda line: self.after(0, self._append, line + "\n"),
            )

        def done(result):
            if isinstance(result, Exception):
                self._append(f"\nError: {result}\n")
            self._append(f"{SEPARATOR}\n")
            self._set_busy(False)

        self._run_bg(work, done)
