# Python AI Agent

A dual-model AI agent system featuring a **Planner** and a **Builder**, support for multiple API providers (Venice, OpenCode, OpenRouter, and custom), context window trimming for cost savings, cost control during tool execution, full system tool access (file ops, shell, web, code execution), real-time streaming responses, JSON chat history persistence, and a modern CustomTkinter GUI.
