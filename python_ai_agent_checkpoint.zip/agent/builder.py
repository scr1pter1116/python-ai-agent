import json
from agent.providers import get_provider
from agent.config import config_manager
from agent.tools import tool_registry

MAX_STEPS = 15
BUILDER_MAX_TOKENS = 800  # low cap: the builder should mostly emit tool calls, not prose

SYSTEM_PROMPT = (
    "You are the Builder agent with full access to the local system through tools. "
    "Execute the plan step by step by calling tools. Keep your text minimal: no narration "
    "between tool calls, only short status notes. When the task is complete, reply with a "
    "brief summary (max 3 sentences) and make no further tool calls."
)


class BuilderAgent:
    def execute_task(self, plan: str, user_prompt: str, callback=None) -> str:
        cfg = config_manager.config["builder"]
        provider = get_provider(cfg["provider"])
        model = cfg["model"]
        tools = tool_registry.get_tool_definitions()

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Original request:\n{user_prompt}\n\nPlan:\n{plan}\n\nExecute the plan now."},
        ]

        for step in range(1, MAX_STEPS + 1):
            message = provider.chat(
                model=model,
                messages=messages,
                max_tokens=BUILDER_MAX_TOKENS,
                temperature=0.2,
                tools=tools,
            )

            content = (message.get("content") or "").strip()
            tool_calls = message.get("tool_calls") or []

            assistant_msg = {"role": "assistant", "content": content}
            if tool_calls:
                assistant_msg["tool_calls"] = tool_calls
            messages.append(assistant_msg)

            if not tool_calls:
                if callback and content:
                    callback(f"\n[Builder] {content}")
                return content

            for call in tool_calls:
                fn = call.get("function", {})
                name = fn.get("name", "")
                args = fn.get("arguments", "{}")
                if callback:
                    callback(f"\n[Builder step {step}] tool: {name} {args[:300]}")

                result = tool_registry.execute(name, args)

                if callback:
                    callback(f"[result] {result[:500]}")

                messages.append({
                    "role": "tool",
                    "tool_call_id": call.get("id", ""),
                    "name": name,
                    "content": result,
                })

        if callback:
            callback(f"\n[Builder] stopped after {MAX_STEPS} steps without finishing.")
        return "Stopped: step limit reached."
