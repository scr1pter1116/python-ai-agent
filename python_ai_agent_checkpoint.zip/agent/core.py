from agent.planner import PlannerAgent
from agent.builder import BuilderAgent
from agent.context_manager import ContextManager
from agent.config import config_manager


class AgentOrchestrator:
    def __init__(self):
        self.planner = PlannerAgent()
        self.builder = BuilderAgent()

    def _context_manager(self) -> ContextManager:
        s = config_manager.config["settings"]
        return ContextManager(
            max_tokens=s.get("max_context_tokens", 32000),
            preserve_messages=s.get("preserve_messages", 6),
        )

    def run(self, user_prompt: str, on_text=None, on_status=None) -> str:
        """on_text(str): streamed text chunks. on_status(str): whole status lines."""
        def status(msg):
            if on_status:
                on_status(msg)

        def text(chunk):
            if on_text:
                on_text(chunk)

        history = config_manager.load_history()
        trimmed = self._context_manager().trim(
            [{"role": m["role"], "content": m["content"]} for m in history]
        )

        status("--- Planner ---")
        plan = self.planner.create_plan(user_prompt, trimmed, callback=text)
        text("\n")

        status("--- Builder ---")
        result = self.builder.execute_task(plan, user_prompt, callback=status)

        history.append({"role": "user", "content": user_prompt})
        history.append({"role": "assistant", "content": f"Plan:\n{plan}\n\nResult:\n{result}"})
        config_manager.save_history(history)
        return result
