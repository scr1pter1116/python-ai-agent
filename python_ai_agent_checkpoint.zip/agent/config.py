import os
import json
from pathlib import Path
from dotenv import load_dotenv
from agent.providers.registry import get_default_providers

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "config.json"
HISTORY_PATH = BASE_DIR / "chat_history.json"

default_providers_dict = {}
for name, url in get_default_providers().items():
    env_key_name = f"{name.upper().replace(' ', '_').replace('(', '').replace(')', '')}_API_KEY"
    default_providers_dict[name] = {
        "api_key": os.getenv(env_key_name, ""),
        "base_url": url
    }

DEFAULT_CONFIG = {
    "providers": default_providers_dict,
    "planner": {
        "provider": "OpenRouter",
        "model": "anthropic/claude-3.5-sonnet"
    },
    "builder": {
        "provider": "OpenRouter",
        "model": "openai/gpt-4o-mini"
    },
    "settings": {
        "max_context_tokens": 32000,
        "trim_strategy": "oldest_first",
        "preserve_messages": 6,
        "cost_saving_mode": True
    }
}

class ConfigManager:
    def __init__(self):
        self.config = self.load_config()
        self.ensure_history_file()

    def load_config(self):
        if CONFIG_PATH.exists():
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return self._deep_merge(DEFAULT_CONFIG, data)
            except Exception:
                return DEFAULT_CONFIG.copy()
        return DEFAULT_CONFIG.copy()

    def save_config(self):
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=4)

    def _deep_merge(self, base, override):
        result = base.copy()
        for k, v in override.items():
            if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                result[k] = self._deep_merge(result[k], v)
            else:
                result[k] = v
        return result

    def ensure_history_file(self):
        if not HISTORY_PATH.exists():
            self.save_history([])

    def load_history(self):
        if HISTORY_PATH.exists():
            try:
                with open(HISTORY_PATH, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return []
        return []

    def save_history(self, history):
        HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(HISTORY_PATH, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=4)

    def clear_history(self):
        self.save_history([])

    def add_provider(self, name: str, base_url: str, api_key: str = ""):
        name = name.strip()
        base_url = base_url.strip().rstrip("/")
        if not name or not base_url.startswith(("http://", "https://")):
            raise ValueError("Provider needs a name and a http(s) base URL.")
        if name in self.config["providers"]:
            raise ValueError(f"Provider '{name}' already exists.")
        self.config["providers"][name] = {"api_key": api_key, "base_url": base_url}
        self.save_config()

config_manager = ConfigManager()
