from agent.providers import get_provider
from agent.config import config_manager

PLANNER_MAX_TOKENS = 1200

SYSTEM_PROMPT = (
    "You are the Planner agent. Analyze the user's request and produce a concise, numbered, "
    "step-by-step plan that a builder agent with tools (read/write files, run shell commands, "
    "run Python code, fetch URLs) can execute. No preamble, no code unless essential."
)


class PlannerAgent:
    def create_plan(self, user_prompt: str, context_history: list[dict] | None = None, callback=None) -> str:
        cfg = config_manager.config["planner"]
        provider = get_provider(cfg["provider"])

        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        if context_history:
            messages.extend(context_history)
        messages.append({"role": "user", "content": user_prompt})

        parts = []
        for delta in provider.stream_chat(
            model=cfg["model"],
            messages=messages,
            max_tokens=PLANNER_MAX_TOKENS,
            temperature=0.3,
        ):
            parts.append(delta)
            if callback:
                callback(delta)
        return "".join(parts).strip()
