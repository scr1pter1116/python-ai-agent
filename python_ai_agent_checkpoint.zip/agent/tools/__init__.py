import os
import sys
import json
import subprocess
import tempfile
import traceback

import requests

MAX_OUTPUT = 8000


def _clip(text: str) -> str:
    if len(text) <= MAX_OUTPUT:
        return text
    return text[:MAX_OUTPUT] + f"\n... [truncated {len(text) - MAX_OUTPUT} chars]"


def _format_proc(result: subprocess.CompletedProcess) -> str:
    out = f"Exit Code: {result.returncode}\n"
    if result.stdout:
        out += f"STDOUT:\n{result.stdout}\n"
    if result.stderr:
        out += f"STDERR:\n{result.stderr}\n"
    return _clip(out)


class ToolRegistry:
    def __init__(self):
        self.tools = {}
        self._register_defaults()

    def _add(self, name, description, parameters, func):
        self.tools[name] = {
            "description": description,
            "parameters": parameters,
            "function": func,
        }

    def get_tool_definitions(self) -> list[dict]:
        return [
            {
                "type": "function",
                "function": {
                    "name": name,
                    "description": t["description"],
                    "parameters": t["parameters"],
                },
            }
            for name, t in self.tools.items()
        ]

    def execute(self, name: str, arguments: str | dict) -> str:
        """Run a tool. Always returns a string so it can be sent back to the model."""
        if name not in self.tools:
            return f"Error: tool '{name}' does not exist."
        try:
            args = json.loads(arguments) if isinstance(arguments, str) else (arguments or {})
        except json.JSONDecodeError as e:
            return f"Error: invalid JSON arguments for '{name}': {e}"
        try:
            return _clip(str(self.tools[name]["function"](**args)))
        except Exception as e:
            return f"Error running '{name}': {e}\n{traceback.format_exc(limit=3)}"

    def _register_defaults(self):
        def read_file(path: str):
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()

        def write_file(path: str, content: str):
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            return f"Wrote {len(content)} chars to {path}"

        def run_shell(command: str, timeout: int = 120):
            result = subprocess.run(
                command, shell=True, capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=timeout,
            )
            return _format_proc(result)

        def run_python_code(code: str, timeout: int = 120):
            # Use the same interpreter that runs the agent (not whatever "python" is on PATH).
            fd, temp_path = tempfile.mkstemp(suffix=".py", prefix="agent_exec_")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(code)
                result = subprocess.run(
                    [sys.executable, temp_path], capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=timeout,
                )
                return _format_proc(result)
            finally:
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

        def fetch_url(url: str):
            resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=20)
            return f"HTTP {resp.status_code}\n{resp.text}"

        str_prop = {"type": "string"}
        self._add("read_file", "Read a text file and return its contents.",
                  {"type": "object", "properties": {"path": {"type": "string", "description": "File path"}},
                   "required": ["path"]}, read_file)
        self._add("write_file", "Write text to a file, creating parent directories if needed. Overwrites existing files.",
                  {"type": "object", "properties": {"path": str_prop, "content": str_prop}, "required": ["path", "content"]},
                  write_file)
        self._add("run_shell", "Run a shell command on this Windows machine and return its output.",
                  {"type": "object", "properties": {"command": str_prop,
                                                    "timeout": {"type": "integer", "description": "Seconds, default 120"}},
                   "required": ["command"]}, run_shell)
        self._add("run_python_code", "Execute Python code with full system access and return its output.",
                  {"type": "object", "properties": {"code": str_prop,
                                                    "timeout": {"type": "integer", "description": "Seconds, default 120"}},
                   "required": ["code"]}, run_python_code)
        self._add("fetch_url", "Fetch a URL over HTTP(S) and return the status and body (truncated).",
                  {"type": "object", "properties": {"url": str_prop}, "required": ["url"]}, fetch_url)


tool_registry = ToolRegistry()
