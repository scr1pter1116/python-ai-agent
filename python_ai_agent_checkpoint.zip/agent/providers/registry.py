# OpenAI-compatible base URLs. Any provider not listed here can be added
# from the GUI as a custom provider (name + base URL).
POPULAR_PROVIDERS = {
    "Venice": "https://api.venice.ai/api/v1",
    "OpenCode": "https://api.opencode.ai/v1",
    "OpenRouter": "https://openrouter.ai/api/v1",
    "OpenAI": "https://api.openai.com/v1",
    "Groq": "https://api.groq.com/openai/v1",
    "DeepSeek": "https://api.deepseek.com/v1",
    "Mistral": "https://api.mistral.ai/v1",
    "Together AI": "https://api.together.xyz/v1",
    "Perplexity": "https://api.perplexity.ai",
    "Local (LM Studio / Ollama)": "http://localhost:11434/v1",
}


def get_default_providers():
    return POPULAR_PROVIDERS
