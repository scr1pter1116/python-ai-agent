import json
from abc import ABC, abstractmethod
import requests


class ProviderError(Exception):
    pass


class BaseProvider(ABC):
    def __init__(self, name: str, api_key: str, base_url: str):
        self.name = name
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    @abstractmethod
    def fetch_models(self) -> list[str]:
        """Fetch available model IDs from the provider API."""

    @abstractmethod
    def chat(self, model: str, messages: list[dict], max_tokens: int, temperature: float = 0.2,
             tools: list[dict] | None = None) -> dict:
        """Single non-streaming completion. Returns the assistant message dict."""

    @abstractmethod
    def stream_chat(self, model: str, messages: list[dict], max_tokens: int, temperature: float = 0.2):
        """Yields text deltas as they arrive (no tools)."""


class OpenAICompatibleProvider(BaseProvider):
    def _headers(self) -> dict:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        if "openrouter.ai" in self.base_url:
            headers["HTTP-Referer"] = "https://github.com/python-ai-agent"
            headers["X-Title"] = "Python AI Agent"
        return headers

    def fetch_models(self) -> list[str]:
        if not self.api_key or not self.base_url:
            return []
        resp = requests.get(f"{self.base_url}/models", headers=self._headers(), timeout=15)
        if resp.status_code != 200:
            raise ProviderError(f"{self.name}: model list failed ({resp.status_code}): {resp.text[:200]}")
        data = resp.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        models = []
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict) and "id" in item:
                    models.append(item["id"])
                elif isinstance(item, str):
                    models.append(item)
        return sorted(models)

    def _payload(self, model, messages, max_tokens, temperature, stream, tools=None):
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": stream,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        return payload

    def chat(self, model, messages, max_tokens, temperature=0.2, tools=None) -> dict:
        resp = requests.post(
            f"{self.base_url}/chat/completions",
            headers=self._headers(),
            json=self._payload(model, messages, max_tokens, temperature, False, tools),
            timeout=180,
        )
        if resp.status_code != 200:
            raise ProviderError(f"{self.name} API error ({resp.status_code}): {resp.text[:500]}")
        return resp.json()["choices"][0]["message"]

    def stream_chat(self, model, messages, max_tokens, temperature=0.2):
        with requests.post(
            f"{self.base_url}/chat/completions",
            headers=self._headers(),
            json=self._payload(model, messages, max_tokens, temperature, True),
            stream=True,
            timeout=180,
        ) as resp:
            if resp.status_code != 200:
                raise ProviderError(f"{self.name} API error ({resp.status_code}): {resp.text[:500]}")
            for raw in resp.iter_lines(decode_unicode=True):
                if not raw or not raw.startswith("data:"):
                    continue
                chunk = raw[len("data:"):].strip()
                if chunk == "[DONE]":
                    break
                try:
                    delta = json.loads(chunk)["choices"][0].get("delta", {})
                except (json.JSONDecodeError, KeyError, IndexError):
                    continue
                text = delta.get("content")
                if text:
                    yield text
