from agent.providers.base import OpenAICompatibleProvider, BaseProvider, ProviderError


def get_provider(provider_name: str) -> BaseProvider:
    from agent.config import config_manager

    cfg = config_manager.config["providers"].get(provider_name, {})
    return OpenAICompatibleProvider(
        provider_name,
        cfg.get("api_key", ""),
        cfg.get("base_url", ""),
    )
