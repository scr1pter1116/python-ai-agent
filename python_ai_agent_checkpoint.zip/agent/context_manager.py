class ContextManager:
    """Keeps the conversation under a token budget by dropping the oldest turns.

    Token counts are estimated at ~4 characters per token. The most recent
    `preserve_messages` are always kept; older messages are dropped from the
    front until the estimate fits. A single note records how many turns were dropped.
    """

    def __init__(self, max_tokens: int = 32000, preserve_messages: int = 6):
        self.max_tokens = max_tokens
        self.preserve_messages = max(1, preserve_messages)

    @staticmethod
    def estimate_tokens(messages: list[dict]) -> int:
        return sum(len(str(m.get("content", ""))) for m in messages) // 4

    def trim(self, messages: list[dict]) -> list[dict]:
        if self.estimate_tokens(messages) <= self.max_tokens:
            return list(messages)

        kept = list(messages[-self.preserve_messages:])
        dropped = len(messages) - len(kept)
        # Drop more from the front until within budget (never drop the last message).
        while len(kept) > 1 and self.estimate_tokens(kept) > self.max_tokens:
            kept.pop(0)
            dropped += 1

        if dropped:
            kept.insert(0, {"role": "system",
                            "content": f"[{dropped} earlier messages were trimmed to save tokens.]"})
        return kept
